﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NUnit.Framework;
namespace UnitTestProject_Sep9_Day2.Csharp
{
	//[TestFixture]
	class AMTest
	{
		public int var1=100;
		public void method1()
		{
			Console.WriteLine("AMTest - method1");
		}

	}
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestProject_Sep9_Day2.Csharp
{
	class AgeException : Exception
	{
		public AgeException(string message): base(message)
		{

		}
	}
}

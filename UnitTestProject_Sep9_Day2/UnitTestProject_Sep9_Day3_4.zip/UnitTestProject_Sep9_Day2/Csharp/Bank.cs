﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestProject_Sep9.Csharp
{
	interface Bank
	{
   	    void debit();
		void credit();
	}
}

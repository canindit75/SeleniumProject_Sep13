﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestProject_Sep9_Day2.Selenium
{
	static class CP_ObjectRepos
	{
		public static string agexpath = "//*[@id='cage']";
	}
	static class BMIP_ObjectRepos
	{
		public static string agexpath = "//*[@id='cage']";
	}
}

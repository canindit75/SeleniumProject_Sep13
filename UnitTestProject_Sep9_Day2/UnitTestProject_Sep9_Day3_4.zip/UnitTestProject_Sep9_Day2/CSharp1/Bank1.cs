﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnitTestProject_Sep9_Day2.CSharp1
{
	public abstract class Bank1
	{

		public abstract void Debit();
		public abstract void Credit();

	}
}
